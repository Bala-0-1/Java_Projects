package fourte;



public class DataClass {
    private int[] num;
    public int[] getNum() {
        return num;
    }

    public void setNum(int[] num) {
        this.num = num;
    }

    public DataClass(){

    }

    public DataClass(int[] num){
        this.num = num;
    }


}
